<?php
namespace app\index\controller;

use think\Request;
use think\Controller;

class Index extends Controller
{
    public function index()
    {
        return $this->fetch('index/index');
    }

    public function upload()
    {
        if (request()->method() === 'GET')
        {
            return $this->fetch('index/upload');
        }
        $file = request()->file('image');
        $info = $file->validate(['size'=>5242880,'ext'=>'jpg,png,gif,jpeg'])->move('./uploads');
        if($info){
            $this->assign('msg',$_SERVER['HTTP_HOST']."/uploads/".$info->getSaveName());
            return  $this->fetch('index/show');
        }else{
            $this->assign('msg','upload filed');
            return  $this->fetch('index/show');
        }
    }

    public function download(Request $request)
    {
        if (request()->method() === 'GET')
        {
            return $this->fetch('index/download');
        }
        $url= $request->param("url");
        $scheme = parse_url($url, PHP_URL_SCHEME);
        if(strstr($scheme,"php")){
            $this->assign('msg',"not allow");
            return  $this->fetch('index/show');
        }
        $maxSize = 5242880;
        $limitExtension = array_map(function ($ext) {
            return ltrim($ext, '.');
        }, [".png", ".jpg", ".gif",".jpeg"]);
        $allowTypes = array_map(function ($ext) {
            return "image/{$ext}";
        }, $limitExtension);
        $content = file_get_contents($url);
        $img = getimagesizefromstring($content);
        if ($img && in_array($img['mime'], $allowTypes))
        {
            $ext = explode('/',$img['mime'])[1];
            $size = strlen($content);
            if (in_array($ext, $limitExtension) && $size <= $maxSize) {
                $filename = \bin2hex(\random_bytes(10)) . '.' . $ext;
                file_put_contents("./uploads/{$filename}", $content);
                $this->assign('msg',$_SERVER['HTTP_HOST']."/uplods/{$filename}");
                return  $this->fetch('index/show');
            } else {
                $this->assign('msg',"download failed");
                return  $this->fetch('index/show');
            }
        } else {
            $this->assign('msg',"only images");
            return  $this->fetch('index/show');
        }

    }
}